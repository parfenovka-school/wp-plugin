=== Plugin Name ===
Contributors: ProjectSoft
Donate link: https://github.com/ProjectSoft-STUDIONIONS/
Tags: comments, spam
Requires at least: 1.0.0
Tested up to: 3.4
Stable tag: 4.3
License: MIT
License URI: https://mit-license.org/

